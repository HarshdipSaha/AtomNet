@echo off
REM Build script for ACL/EMNLP format paper

if exist atomnet_acl.tex (
    pdflatex -interaction=nonstopmode atomnet_acl.tex
    bibtex atomnet_acl.aux
    pdflatex -interaction=nonstopmode atomnet_acl.tex
    pdflatex -interaction=nonstopmode atomnet_acl.tex
    echo.
    echo Build complete. Open atomnet_acl.pdf to view the paper.
) else (
    echo Error: atomnet_acl.tex not found
)

pause
